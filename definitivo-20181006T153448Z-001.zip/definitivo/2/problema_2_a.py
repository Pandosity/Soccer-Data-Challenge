import json
import pandas as pd
from math import sqrt

match_list = json.load(open('./final.json'))

pass_count={}
accu_count={}

#il ciclo seguente inserisce, nei due dizionari qui sopra,
#il numero di passaggi effettuati e riusciti per ciascuna squadra
for event in match_list:
    #Il calcio d'inizio non è taggato e ci causa problemi, quindi
    #imponiamo che ogni passaggio sia o riuscito o sbagliato, tertium non datur.
    if  len(event['tags'])>0:
          if event['eventId']==8 :
                team = event['teamId']
                player = event['playerId']
                accurate = False
                
                #Di seguito controlliamo se il passaggio è accurato
                #Lo facciamo cercando la label corrispondente, includendo nel
                #conto anche i passaggi che wyscout conta come intercettati e accurati
                #nel caso ci siano multiple tag
                for tag in event['tags']:
                    if tag['id']==1801:
                        accurate = True
            
                if team not in pass_count:
                    pass_count[team]={}
                if team not in accu_count:
                    accu_count[team]={}
                
                #Fissiamo qua entrambi i contatori per evitare ci crei problemi
                #qualcuno che sbaglia tutti i passaggi
                if player not in pass_count[team]:
                    pass_count[team][player]=1
                    accu_count[team][player]=0
                else :
                    pass_count[team][player]+=1
                if accurate==True :
                        accu_count[team][player]+=1

francesi=0
croati=0
mediafra=0
mediacro=0
#Nella parte seguente calcoliamo e stampiamo le medie brute-force

for passer in pass_count['France']:
    francesi+=1
    mediafra += float(accu_count['France'][passer])/pass_count['France'][passer]
for passer in pass_count['Croatia']:
    croati+=1
    mediacro += float(accu_count['Croatia'][passer])/pass_count['Croatia'][passer]

mediafra=mediafra/francesi
mediacro=mediacro/croati

#Idem qui, dove calcoliamo e stampiamo le deviazioni brute force

stdfra=0
stdcro=0

for passer in pass_count['France']:
    stdfra += pow(float(accu_count['France'][passer])/pass_count['France'][passer]-mediafra,2)
for passer in pass_count['Croatia']:
    stdcro += pow(float(accu_count['Croatia'][passer])/pass_count['Croatia'][passer]-mediacro,2)
    
stdfra=sqrt(stdfra/francesi)
stdcro=sqrt(stdcro/croati)

#Creiamo il Dataframe che riassume i dati raccolti, ordinandolo con delle etichette
#per evitare che creandolo da dizionario li ordini casualmente
summa=[{'nome_squadra': 'France', 'accuratezza_media_dei_passaggi' : mediafra , 'standard_deviation_accuratezza_media_dei_passaggi' : stdfra},
       {'nome_squadra': 'Croatia', 'accuratezza_media_dei_passaggi' : mediacro , 'standard_deviation_accuratezza_media_dei_passaggi' : stdcro}]
labels=['nome_squadra','accuratezza_media_dei_passaggi','standard_deviation_accuratezza_media_dei_passaggi']
out=pd.DataFrame(summa)
out=out[labels]
out.to_csv('problema_2_a.csv', index=False)