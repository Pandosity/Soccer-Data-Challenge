import json
import math
import pandas as pd

match_list = json.load(open('./final.json'))
player_list= json.load(open('./players.json'))
                            
tack_count={}
won_count={}
kante={}
#Nel lungo ciclo for seguente costruiamo i contatori
#tack_count e won_count, per i tackle effettuati e
#subiti rispettivamente
for event in match_list:
        if event['eventId']==1:
            if event['subEventId']==12:
                player=event['playerId']
                #Dopo esserci ristretti agli eventi che ci interessano,
                #usiamo il parametro victory per la riuscita o meno del tackle
                victory = False
                for tag in event['tags']:
                    if tag['id']==703:
                        victory = True
                if player not in tack_count:
                    tack_count[player]=1
                    won_count[player]=0
                else :
                    tack_count[player]+=1
                if victory==True:
                    won_count[player]+=1

#Qua creiamo il vettore Kante, che incorpora la condizione
#di aver effettuato almeno due tackle. Un altro dato interessante si sarebbe
#ottenuto, a questo punto, calcolando un dizionario della percentuale di tackle
#riusciti, che avrebbe fatto un uso migliore della condizione sul
#numero minimo di tackle.
for player in tack_count:
    if tack_count[player]>1:
        kante[player]=won_count[player]

#qua con la funzione get ordiniamo per numero decresente di tackle
#in un vettore le entrate del dizionario
v = [(k,kante[k]) for k in sorted(kante, key=kante.get, reverse=True)]
#Qua calcoliamo la posizione del quartile del vettore v (che è la stessa 
#di quello del quartile dei tackle vinti) e la mettiamo in formato intero per lavorarci
l=int(math.ceil(float(len(v))/4))

#Qua andiamo a prendere i nomi dei calciatori in players_list, e li mettiamo
#insieme a id e tackle in un vettore di terne, che etichettiamo.
data=[]
names=[]
for i in range(l):
    for player in player_list:
        if player['playerId']==v[i][0]:
           names.append(player['name'])
    data.append((v[i][0],names[i],v[i][1]))
    
labels=['identificativo_calciatore','nome_calciatore','tackle_vinti']

#Qua costruiamo il dataframe e lo esportiamo in csv
out=pd.DataFrame.from_records(data, columns=labels)
out.to_csv('problema_2_b.csv', index=False)



