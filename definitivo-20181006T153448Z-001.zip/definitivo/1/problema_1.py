#Importiamo librerie e dati

import pandas as pd
import json
import statistics

match_list = json.load(open('./data.json'))
match_df=pd.DataFrame(match_list)

players_list = json.load(open('./players.json'))
players_df=pd.DataFrame(players_list)


#Dal dataframe dei giocatori abbiamo individuato gli Id dei giocatori da escludere.
#Abbiamo escluso l'arbitro e quelli che sono entrati nel secondo tempo (la prima sostituzione
#è avvenuta al 55').

#Tuttavia non abbiamo dovuto escludere Fekir che non compare nell'
#elenco, non ci riguarda perchè è entrato all'81'.

#Problema maggiore è Kante, che ha giocato 55' ma non è nell'elenco. Lui non verrà considerato

#Abbiamo cercato a parte i giocatori sostituiti perchè algoritmicamente
#non avremmo avuto dati inequivocabili, dato che un giocatore poteva non essere presente negli eventi
#del primo tempo semplicemente per non aver giocato in maniera attiva (strano ma possibile)

#match45_df e player45_df sono i nostri nuovi dataframe con solo i giocatori che han giocato più di 45 minuti
 
match_0=match_df['playerId']!=0
match_1=match_df['playerId']!=8200
match_2=match_df['playerId']!=69411
match_3=match_df['playerId']!=209091
match_4=match_df['playerId']!=135810

match_45 = match_1 & match_2 & match_3 & match_4 & match_0
match45_df = match_df[match_45]

player1=players_df['playerId'] != 8200
player2=players_df['playerId'] != 69411
player3=players_df['playerId'] != 209091
player4=players_df['playerId'] != 135810
player5=players_df['playerId'] != 0

player45=player1 & player2 & player3 & player4 & player5
player45_df=players_df[player45]

#Eseguiamo un ciclo che scorre su tutti i giocatori che ci interessano.
#Poichè ogni evento possiede due coppie di coordinate, suddividiamo i casi a seconda
#dell' evento per decidere cosa valutare.

mean_x=[]
mean_y=[]
std2=[]
mean_t=[]
team=[]

for pl_id in player45_df['playerId']:
    x_eff=[]
    y_eff=[]
    t1=0
    t2=0
    delta_t=[]
    for i in match45_df.index:
        if (match45_df['playerId'][i]==pl_id): #Per i duelli, i falli e le accelerazioni
            if(match45_df['eventId'][i]==1 or \
               match45_df['eventId'][i]==2 or \
               match45_df['subEventId'][i]==70): 
                y1=match45_df['positions'][i][0]['y']
                x1=match45_df['positions'][i][0]['x']
                y2=match45_df['positions'][i][1]['y']
                x2=match45_df['positions'][i][1]['x']
                y_eff.append(0.5*(y1+y2))    #Le coordinate efficaci sono le medie
                x_eff.append(0.5*(x1+x2))
            
            if(match45_df['subEventId'][i]==90):  #Per i 'Reflex'
                y_eff.append(match45_df['positions'][i][1]['y'])  #le coordinate efficaci
                x_eff.append(match45_df['positions'][i][1]['x'])  #sono le seconde
                
            if(match45_df['subEventId'][i]==91 or \
               match45_df['subEventId'][i]==34):   #Per i Save attemps e i goal kicks 
                y_eff.append(50)                   #mettiamo il portiere in porta
                x_eff.append(0)
                                              #Per goal keeper leaving line
            if(match45_df['eventId'][i]==4):  #facciamo la media tra posizione tra pali
                y1=50                         #e posizione di arrivo
                x1=0
                y2=match45_df['positions'][i][1]['y']
                x2=match45_df['positions'][i][1]['x']
                y_eff.append(0.5*(y1+y2))
                x_eff.append(0.5*(x1+x2))
                
            #Per le clearence, touch, offside, pass, shot, freekick diversi da goal kick
            if (match45_df['subEventId'][i]==71 or \
                match45_df['subEventId'][i]==72 or \
                match45_df['eventId'][i]==6 or \
                match45_df['eventId'][i]==8 or \
                match45_df['eventId'][i]==10 or \
                (match45_df['eventId'][i]==3 and \
                 match45_df['subEventId'][i]!=34)):
                y_eff.append(match45_df['positions'][i][0]['y'])
                x_eff.append(match45_df['positions'][i][0]['x']) #Prendo la prima coordinata
             
            if(match45_df['matchPeriod'][i]=='1H'):  #Guardo gli intervalli nel primo tempo
                if(t1==0):
                    t1=match45_df['eventSec'][i]
                    team.append(match45_df['teamId'][i])
                else:
                    delta_t.append(match45_df['eventSec'][i]-t1)
                    t1=match45_df['eventSec'][i]
            if(match45_df['matchPeriod'][i]=='2H'):  #e separatamente quelle nel secondo
                if(t2==0):
                    t2=match45_df['eventSec'][i]
                else:
                    delta_t.append(match45_df['eventSec'][i]-t2)
                    t2=match45_df['eventSec'][i]
                    
            
    mean_x.append(statistics.mean(x_eff))
    mean_y.append(statistics.mean(y_eff))
    std2.append((statistics.stdev(x_eff))**2+(statistics.stdev(y_eff))**2)
    mean_t.append(statistics.mean(delta_t))
    
#Creiamo il DataFrame finale
out=pd.DataFrame([])
out['identificativo_calciatore']=player45_df.reset_index(drop=True)["playerId"]
out['nome_calciatore']=player45_df.reset_index(drop=True)["name"]
out['squadra_calciatore']=team
out['posizione_media_x']=mean_x
out['posizione_media_y']=mean_y
out['distanza_quadratica_media']=std2
out['tempo_medio_tra_eventi']=mean_t

#Esportiamo in csv
out.to_csv('problema_1.csv', index=False)