import pandas as pd
import math
import json

events = json.load(open('./data.json'))

eventi_totali_globali = {}
#costruisco liste di liste per gli eventi nella griglia. Rapido e indolore
falli_fatti = [[{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}]]
numero_eventi = [[{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}]]
tiri_effettuati = [[{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}]]
#si derivano i falli subiti invertendo i falli fatti dagli avversari. Bisogna ovviamente invertire le zone del campo
falli_subiti = [[{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}]]
passaggi_accurati = [[{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}]]
passaggi_totali = [[{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}]]


for event in events:
	team = event['teamId']
	if team not in eventi_totali_globali:
		eventi_totali_globali[team] = 1
	else:
		eventi_totali_globali[team] = eventi_totali_globali[team] + 1
		
	event_type = event['eventName']
	
#qui calcolo la vera posizione dell'evento
	pos = event["positions"]
	if (event["subEventId"] in [30, 31, 32, 33, 35, 36, 60, 71, 72, 80, 81, 82, 83, 84, 85, 86, 100, 50]) or (event["eventId"]==6):
		coord_griglia = [math.floor(pos[0]["x"]/20.0), math.floor(pos[0]["y"]/20.0)]
	elif event["subEventId"] in [10, 11, 12, 13, 20, 21, 22, 23, 24, 25, 26, 27, 70]:
		coord_griglia = [math.floor((pos[0]["x"]+pos[1]["x"])/(2*20.0)), math.floor((pos[0]["y"]+pos[1]["y"])/(2*20.0))]
	elif event["subEventId"] == 40:
		coord_griglia = [math.floor((0+pos[1]["x"])/(2*20.0)), math.floor((50+pos[1]["y"])/(2*20.0))]
	elif event["subEventId"] in [34, 90, 91]:
		coord_griglia = [0, math.floor(50/20.0)]
	#le coordinate calcolate in questo modo fanno sì che l'ultima griglia sia piu' grande di pochissimo. Questo dà fastidio invertendo per trovare i falli fatti da quelli subiti, ma pazienza, piccolissimo errore e non significativo.	
	
	if coord_griglia[0] == 5:
		coord_griglia[0] = 4
	if coord_griglia[1] == 5:
		coord_griglia[1] = 4
	
	#conto i falli fatti
	if event_type == "Foul":
		if team not in falli_fatti[coord_griglia[0]][coord_griglia[1]]:
			falli_fatti[coord_griglia[0]][coord_griglia[1]][team] = 1
		else:
			falli_fatti[coord_griglia[0]][coord_griglia[1]][team] = falli_fatti[coord_griglia[0]][coord_griglia[1]][team] + 1
			
	#numero eventi
	#devo stare attento a non contare gli eventi due volte, tipo fallo e successivo calcio di punizione. Poiche' eventi come questo appartengono a squadre diverse, non dovrebbe essere un problema.
	if team not in numero_eventi[coord_griglia[0]][coord_griglia[1]]:
		numero_eventi[coord_griglia[0]][coord_griglia[1]][team] = 1
	else:
		numero_eventi[coord_griglia[0]][coord_griglia[1]][team] = numero_eventi[coord_griglia[0]][coord_griglia[1]][team] + 1
			
	#tiri effettuati
	if event_type == "Shot":
		if team not in tiri_effettuati[coord_griglia[0]][coord_griglia[1]]:
			tiri_effettuati[coord_griglia[0]][coord_griglia[1]][team] = 1
		else:
			tiri_effettuati[coord_griglia[0]][coord_griglia[1]][team] = tiri_effettuati[coord_griglia[0]][coord_griglia[1]][team] + 1
        		
	#passaggi
	if event_type == "Pass":
		if team not in passaggi_totali[coord_griglia[0]][coord_griglia[1]]:
			passaggi_totali[coord_griglia[0]][coord_griglia[1]][team] = 0
			passaggi_accurati[coord_griglia[0]][coord_griglia[1]][team] = 0
		passaggi_totali[coord_griglia[0]][coord_griglia[1]][team] = passaggi_totali[coord_griglia[0]][coord_griglia[1]][team] + 1
		accurate = False
		for dic in event["tags"]:
			if dic["id"] == 1801:
				accurate = True
		#PASSAGGI ACCURATI POSSONO ESSERE STATI INTERCETTATI. CONTO ANCHE QUELLI PERCHE' COSI' SEMBRA DIRE LA CONSEGNA. ALTRIMENTI VANNO RIMOSSI DEI PASSAGGI CON TAG 1401
		if accurate:
			passaggi_accurati[coord_griglia[0]][coord_griglia[1]][team] = passaggi_accurati[coord_griglia[0]][coord_griglia[1]][team] + 1
				
teams = eventi_totali_globali.keys()


#controllo generale sulle inizializzazioni
for i in range(5):
	for j in range(5):
		for team in teams:
			if team not in numero_eventi[i][j]:
				numero_eventi[i][j][team] = 0
			if team not in falli_fatti[i][j]:
				falli_fatti[i][j][team] = 0
			if team not in passaggi_totali[i][j]:
				passaggi_totali[i][j][team] = 0
			if team not in passaggi_accurati[i][j]:
				passaggi_accurati[i][j][team] = 0
			if team not in tiri_effettuati[i][j]:
				tiri_effettuati[i][j][team] = 0
			
#falli subiti
falli_subiti = [[{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}]]

for i in range(5):
	for j in range(5):
		for opponent in falli_fatti[i][j].keys():
			for x in teams:
				if x != opponent:
					team = x
			#il numero di falli fatti dagli avversari e' il numero di falli subiti dalla squadra
			falli_subiti[4-i][4-j][team] = falli_fatti[i][j][opponent]


#calcolo le frequenze		
freq_eventi = [[{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}]]
freq_falli = [[{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}]]
freq_tiri = [[{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}]]
prec_passaggi  = [[{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}], [{},{},{},{},{}]]

tot_pass = 0
ok_pass = 0
for i in range(5):
	for j in range(5):
		tot_pass = tot_pass + passaggi_totali[i][j]["France"]
		ok_pass = ok_pass + passaggi_accurati[i][j]["France"]
		for team in teams:
			freq_eventi[i][j][team] = numero_eventi[i][j][team] / eventi_totali_globali[team] * 100
			
			if numero_eventi[i][j][team] != 0:
				freq_tiri[i][j][team] = tiri_effettuati[i][j][team] / numero_eventi[i][j][team] * 100
				freq_falli[i][j][team] = falli_subiti[i][j][team] / numero_eventi[i][j][team] * 100
			else:
				freq_tiri[i][j][team] = 0
				freq_falli[i][j][team] = 0
				
			if passaggi_totali[i][j][team] != 0:
				prec_passaggi[i][j][team] = passaggi_accurati[i][j][team] / passaggi_totali[i][j][team] * 100
			else:
				prec_passaggi[i][j][team] = 0


cosine_similarities = [0, 0, 0, 0]
scalar_products = [0, 0, 0, 0]
norm_fra = [0, 0, 0, 0]
norm_cro = [0, 0, 0, 0]

for i in range(5):
	for j in range(5):
		scalar_products[0] = scalar_products[0] + freq_eventi[i][j]["France"]*freq_eventi[i][j]["Croatia"]
		scalar_products[1] = scalar_products[1] + freq_falli[i][j]["France"]*freq_falli[i][j]["Croatia"]
		scalar_products[2] = scalar_products[2] + freq_tiri[i][j]["France"]*freq_tiri[i][j]["Croatia"]
		scalar_products[3] = scalar_products[3] + prec_passaggi[i][j]["France"]*prec_passaggi[i][j]["Croatia"]
		
		norm_fra[0] = norm_fra[0] + freq_eventi[i][j]["France"]**2
		norm_fra[1] = norm_fra[1] + freq_falli[i][j]["France"]**2
		norm_fra[2] = norm_fra[2] + freq_tiri[i][j]["France"]**2
		norm_fra[3] = norm_fra[3] + prec_passaggi[i][j]["France"]**2
		
		norm_cro[0] = norm_cro[0] + freq_eventi[i][j]["Croatia"]**2
		norm_cro[1] = norm_cro[1] + freq_falli[i][j]["Croatia"]**2
		norm_cro[2] = norm_cro[2] + freq_tiri[i][j]["Croatia"]**2
		norm_cro[3] = norm_cro[3] + prec_passaggi[i][j]["Croatia"]**2
		
for i in range(4):
	cosine_similarities[i] = scalar_products[i] / (norm_fra[i] * norm_cro[i])**0.5


output = [{"tipo_griglia" : 1, "similarity" : cosine_similarities[0]}, {"tipo_griglia" : 2, "similarity" : cosine_similarities[3]}, {"tipo_griglia" : 3, "similarity" : cosine_similarities[2]}, {"tipo_griglia" : 4, "similarity" : cosine_similarities[1]}]
data = pd.DataFrame(output)


col_list = list(data)
#scambio
col_list[0], col_list[1] = col_list[1], col_list[0]
data=data.loc[:,col_list]

data.to_csv("problema_3_b.csv", index=False)